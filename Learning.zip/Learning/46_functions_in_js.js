console.log("This is working ");
function greet(name,liking="from my friend") {
    console.log("hello "+name);
    console.log("how is your day my friend "+liking);
}
function sum(num1,num2,num3) {
    console.log(num1+num2+num3);
    
}
let name1="kartik";
let liking="this"
greet(name1,liking);
sum(1,2,3);
